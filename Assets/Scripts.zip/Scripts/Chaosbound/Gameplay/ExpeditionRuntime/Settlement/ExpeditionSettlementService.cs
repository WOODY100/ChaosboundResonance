using Chaosbound.Content.Expeditions.Runtime.Configs;
using Chaosbound.Content.Items;
using Chaosbound.Gameplay.ExpeditionRuntime.Runtime;
using Chaosbound.Gameplay.Inventory.Persistent;
using Chaosbound.Gameplay.Inventory.Runtime;
using Chaosbound.Gameplay.Items.Runtime;
using Chaosbound.Gameplay.MetaProgression.Persistent;
using Chaosbound.Gameplay.Currency.Persistent;
using System;
using System.Collections.Generic;

namespace Chaosbound.Gameplay.ExpeditionRuntime.Settlement
{
    public sealed class ExpeditionSettlementService
    {
        private readonly PersistentItemInventoryState persistentItems;
        private readonly SecureInventoryState secureInventory;
        private readonly PersistentMaterialsState persistentMaterials;
        private readonly PersistentMetaRuntime persistentMetaRuntime;

        private readonly ExpeditionRewardItemResolver
            expeditionRewardItemResolver;

        private readonly ItemInstanceFactory
            itemInstanceFactory;

        private readonly PersistentCurrencyState persistentCurrency;
        private bool isCurrencySettled;

        private bool isSettled;

        public ExpeditionSettlementService(
            PersistentItemInventoryState persistentItems,
            PersistentMaterialsState persistentMaterials,
            PersistentMetaRuntime persistentMetaRuntime,
            SecureInventoryState secureInventory,
            ExpeditionRewardItemResolver expeditionRewardItemResolver,
            ItemInstanceFactory itemInstanceFactory,
            PersistentCurrencyState persistentCurrency)
        {
            this.persistentItems =
                persistentItems ??
                throw new ArgumentNullException(nameof(persistentItems));

            this.persistentMaterials =
                persistentMaterials ??
                throw new ArgumentNullException(nameof(persistentMaterials));

            this.persistentMetaRuntime =
                persistentMetaRuntime ??
                throw new ArgumentNullException(
                    nameof(persistentMetaRuntime));

            this.secureInventory =
                secureInventory ??
                throw new ArgumentNullException(nameof(secureInventory));

            this.expeditionRewardItemResolver =
                expeditionRewardItemResolver ??
                throw new ArgumentNullException(
                    nameof(expeditionRewardItemResolver));

            this.itemInstanceFactory =
                itemInstanceFactory ??
                throw new ArgumentNullException(
                    nameof(itemInstanceFactory));

            this.persistentCurrency =
                persistentCurrency ??
                throw new ArgumentNullException(
                    nameof(persistentCurrency));
        }

        public bool IsSettled =>
            isSettled;

        public bool TrySettle(
            ExpeditionRuntimeState expeditionState,
            RuntimeExpeditionConfig expeditionConfig,
            out ExpeditionSettlementResult result)
        {
            if (isSettled)
            {
                result = CreateFailureResult();
                return false;
            }

            if (expeditionState == null)
            {
                result = CreateFailureResult();
                return false;
            }

            if (expeditionConfig == null)
            {
                result = CreateFailureResult();
                return false;
            }

            SettlementPlan plan;

            if (!TryBuildPlan(
                    expeditionState,
                    expeditionConfig,
                    out plan))
            {
                result = CreateFailureResult();
                return false;
            }

            Commit(plan);

            expeditionState.Currency.Clear();
            isCurrencySettled = true;

            isSettled = true;

            result =
                new ExpeditionSettlementResult(
                    true,
                    plan.ExpeditionItemCount,
                    plan.MaterialAmounts,
                    plan.CompletionRewardItems,
                    plan.MetaExperience);

            return true;
        }

        private bool TryBuildPlan(
            ExpeditionRuntimeState expeditionState,
            RuntimeExpeditionConfig expeditionConfig,
            out SettlementPlan plan)
        {
            plan = new SettlementPlan();

            if (!TryPrepareExpeditionItems(
                expeditionState,
                plan))
            {
                return false;
            }

            if (!TryPrepareSecureItems(plan))
            {
                return false;
            }

            if (!TryPrepareMaterials(
                expeditionState,
                plan))
            {
                return false;
            }

            if (!TryPrepareCurrency(
                expeditionState,
                plan))
            {
                return false;
            }

            if (!TryPrepareCompletionReward(
                    expeditionConfig,
                    plan))
            {
                return false;
            }

            return true;
        }

        private bool TryPrepareSecureItems(
            SettlementPlan plan)
        {
            IReadOnlyList<InventorySlot> slots =
                secureInventory.GetSlots();

            for (int i = 0; i < slots.Count; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null || !slot.IsOccupied)
                    continue;

                ItemInstance item = slot.Item;

                if (item == null)
                    return false;

                plan.SecureItems.Add(item);
            }

            return true;
        }

        private bool TryPrepareExpeditionItems(
            ExpeditionRuntimeState expeditionState,
            SettlementPlan plan)
        {
            IReadOnlyList<InventorySlot> slots =
                expeditionState.Inventory.GetSlots();

            for (int i = 0; i < slots.Count; i++)
            {
                InventorySlot slot = slots[i];

                if (slot == null || !slot.IsOccupied)
                    continue;

                ItemInstance item = slot.Item;

                if (item == null)
                    return false;

                plan.ExpeditionItems.Add(item);
            }

            plan.ExpeditionItemCount =
                plan.ExpeditionItems.Count;

            return true;
        }

        private bool TryPrepareMaterials(
            ExpeditionRuntimeState expeditionState,
            SettlementPlan plan)
        {
            IReadOnlyDictionary<string, int> amounts =
                expeditionState.Materials.GetAmounts();

            foreach (
                KeyValuePair<string, int> entry
                in amounts)
            {
                string contentId =
                    entry.Key?.Trim();

                int amount = entry.Value;

                if (string.IsNullOrWhiteSpace(contentId))
                    return false;

                if (amount <= 0)
                    return false;

                int currentAmount =
                    persistentMaterials.GetAmount(
                        contentId);

                if (amount >
                    int.MaxValue - currentAmount)
                {
                    return false;
                }

                plan.MaterialAmounts[contentId.Trim()] =
                    amount;
            }

            return true;
        }

        private bool TryPrepareCurrency(
            ExpeditionRuntimeState expeditionState,
            SettlementPlan plan)
        {
            IReadOnlyDictionary<string, int> amounts =
                expeditionState.Currency.GetAmounts();

            foreach (
                KeyValuePair<string, int> entry
                in amounts)
            {
                string contentId = entry.Key?.Trim();
                int amount = entry.Value;

                if (string.IsNullOrWhiteSpace(contentId))
                    return false;

                if (amount <= 0)
                    return false;

                int currentAmount =
                    persistentCurrency.GetAmount(contentId);

                if (currentAmount < 0)
                    return false;

                if (amount > int.MaxValue - currentAmount)
                    return false;

                plan.CurrencyAmounts[contentId] =
                    amount;
            }

            return true;
        }

        private bool TryPrepareCompletionReward(
            RuntimeExpeditionConfig expeditionConfig,
            SettlementPlan plan)
        {
            if (expeditionConfig.Rewards == null)
                return false;

            IReadOnlyList<string> itemContentIds =
                expeditionConfig.Rewards.ItemContentIds;

            if (itemContentIds != null)
            {
                for (int i = 0; i < itemContentIds.Count; i++)
                {
                    string itemContentId = itemContentIds[i];

                    if (string.IsNullOrWhiteSpace(itemContentId))
                        continue;

                    ItemBaseData itemData;

                    if (!expeditionRewardItemResolver.TryResolve(
                            itemContentId,
                            out itemData))
                    {
                        return false;
                    }

                    if (itemData == null)
                        return false;

                    ItemInstance item =
                        itemInstanceFactory.Create(itemData);

                    if (item == null)
                        return false;

                    plan.CompletionRewardItems.Add(item);
                }
            }

            int metaExperience =
                expeditionConfig.Rewards.MetaExperience;

            if (metaExperience < 0)
                return false;

            if (!persistentMetaRuntime.State.CanAddExperience(
                    metaExperience))
            {
                return false;
            }

            plan.MetaExperience = metaExperience;

            return true;
        }

        private void Commit(
            SettlementPlan plan)
        {
            for (int i = 0;
                 i < plan.ExpeditionItems.Count;
                 i++)
            {
                ItemInstance item =
                    plan.ExpeditionItems[i];

                if (!persistentItems.TryAdd(item))
                {
                    throw new InvalidOperationException(
                        "Settlement commit failed while " +
                        "adding an expedition item.");
                }
            }

            for (int i = 0;
                 i < plan.SecureItems.Count;
                 i++)
            {
                ItemInstance item =
                    plan.SecureItems[i];

                if (!persistentItems.TryAdd(item))
                {
                    throw new InvalidOperationException(
                        "Settlement commit failed while " +
                        "adding a secure item.");
                }
            }

            foreach (
                KeyValuePair<string, int> entry
                in plan.MaterialAmounts)
            {
                if (!persistentMaterials.Add(
                        entry.Key,
                        entry.Value))
                {
                    throw new InvalidOperationException(
                        "Settlement commit failed while " +
                        "adding expedition materials.");
                }
            }

            for (int i = 0; i < plan.CompletionRewardItems.Count; i++)
            {
                ItemInstance item = plan.CompletionRewardItems[i];

                if (!persistentItems.TryAdd(item))
                {
                    throw new InvalidOperationException(
                        "Settlement commit failed while " +
                        "adding a completion reward item.");
                }
            }

            if (plan.MetaExperience > 0)
            {
                persistentMetaRuntime.AddMetaExperience(
                    plan.MetaExperience);
            }

            RemoveSettledSecureItems(plan);

            CommitCurrency(plan);
        }

        private void CommitCurrency(
            SettlementPlan plan)
        {
            foreach (
                KeyValuePair<string, int> entry
                in plan.CurrencyAmounts)
            {
                if (!persistentCurrency.Add(
                    entry.Key,
                    entry.Value))
                {
                    throw new InvalidOperationException(
                        "Settlement commit failed while " +
                        "adding expedition currency.");
                }
            }
        }

        private void RemoveSettledSecureItems(
            SettlementPlan plan)
        {
            for (int i = 0;
                 i < plan.SecureItems.Count;
                 i++)
            {
                ItemInstance expectedItem =
                    plan.SecureItems[i];

                bool removed = false;

                IReadOnlyList<InventorySlot> slots =
                    secureInventory.GetSlots();

                for (int slotIndex = 0;
                     slotIndex < slots.Count;
                     slotIndex++)
                {
                    InventorySlot slot = slots[slotIndex];

                    if (slot == null ||
                        !slot.IsOccupied)
                    {
                        continue;
                    }

                    if (slot.Item != expectedItem)
                        continue;

                    if (!secureInventory.TryRemoveAt(
                            slotIndex,
                            out ItemInstance removedItem))
                    {
                        throw new InvalidOperationException(
                            "Settlement commit failed while " +
                            "removing a settled secure item.");
                    }

                    if (removedItem != expectedItem)
                    {
                        throw new InvalidOperationException(
                            "Settlement commit removed an unexpected " +
                            "secure item.");
                    }

                    removed = true;
                    break;
                }

                if (!removed)
                {
                    throw new InvalidOperationException(
                        "Settlement commit could not locate a " +
                        "secure item that was prepared for settlement.");
                }
            }
        }

        private ExpeditionSettlementResult
            CreateFailureResult()
        {
            return new ExpeditionSettlementResult(
                false,
                0,
                new Dictionary<string, int>(),
                null,
                0);
        }

        public bool TrySettleCurrency(
            ExpeditionRuntimeState expeditionState)
        {
            if (expeditionState == null)
                return false;

            if (isCurrencySettled)
                return true;

            SettlementPlan plan =
                new SettlementPlan();

            if (!TryPrepareCurrency(
                expeditionState,
                plan))
            {
                return false;
            }

            CommitCurrency(plan);

            expeditionState.Currency.Clear();

            isCurrencySettled = true;

            return true;
        }

        public void ResetForNewExpedition()
        {
            isCurrencySettled = false;
            isSettled = false;
        }

        private sealed class SettlementPlan
        {
            public readonly List<ItemInstance>
                ExpeditionItems =
                    new List<ItemInstance>();

            public readonly List<ItemInstance>
                SecureItems =
                    new List<ItemInstance>();

            public readonly Dictionary<string, int>
                MaterialAmounts =
                    new Dictionary<string, int>(
                        StringComparer.Ordinal);

            public readonly Dictionary<string, int>
                CurrencyAmounts =
                    new Dictionary<string, int>(
                        StringComparer.Ordinal);

            public int ExpeditionItemCount;

            public readonly List<ItemInstance> CompletionRewardItems =
                new List<ItemInstance>();

            public int MetaExperience;
        }
    }
}