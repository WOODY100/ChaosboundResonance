public enum EnemyAbilityExecutionType
{
    Projectile
}