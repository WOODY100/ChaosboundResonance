using System;

namespace Chaosbound.SkillTree
{
    [Serializable]
    public abstract class SkillTreeEffect
    {
    }
}