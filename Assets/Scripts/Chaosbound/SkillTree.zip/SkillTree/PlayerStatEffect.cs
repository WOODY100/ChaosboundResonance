using System;

namespace Chaosbound.SkillTree
{
    [Serializable]
    public sealed class PlayerStatEffect : SkillTreeEffect
    {
        public StatType StatType;
        public ModifierType ModifierType;
        public float Value;
    }

    [Serializable]
    public sealed class GlobalSkillModifierEffect : SkillTreeEffect
    {
        public SkillModifierType ModifierType;
        public float Value;
    }

    [Serializable]
    public sealed class RuleEffect : SkillTreeEffect
    {
    }
}