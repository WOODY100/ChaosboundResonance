using Chaosbound.Content.Expeditions.Enums.Spawn;
using Chaosbound.Content.Expeditions.Runtime.References;
using Chaosbound.Content.Expeditions.Runtime.Spawn;
using Chaosbound.Gameplay.Spawn.Definitions;
using Chaosbound.Gameplay.Spawn.Domain;
using Chaosbound.Gameplay.Spawn.Factories;
using Chaosbound.Gameplay.Spawn.Models;
using Chaosbound.Gameplay.Spawn.Scheduling;
using Chaosbound.Gameplay.Spawn.ValueObjects;
using Chaosbound.Gameplay.ExpeditionRuntime.Runtime;
using System;
using UnityEngine;

namespace Chaosbound.Gameplay.Spawn.Validation
{
    /// <summary>
    /// Builds a minimal Spawn Runtime validation environment
    /// using the production runtime components.
    /// </summary>
    public sealed class SpawnRuntimeValidationBuilder
    {
        private EnemyVariantData enemy;

        public SpawnRuntimeValidationBuilder WithEnemy(
            EnemyVariantData enemy)
        {
            this.enemy =
                enemy
                ?? throw new ArgumentNullException(nameof(enemy));

            return this;
        }

        public SpawnRuntimeValidationContext Build()
        {
            EnemyVariantData enemy =
                BuildEnemy();

            MaterializableDefinition materializable =
                BuildMaterializable(enemy);

            SpawnExecutionPlanEntry executionEntry =
                BuildExecutionPlanEntry(materializable);

            SpawnJobIdentity identity =
                BuildSpawnJobIdentity();

            SpawnJob job =
                BuildSpawnJob(
                    identity,
                    executionEntry);

            RuntimeSpawnConfig spawnConfig =
                BuildRuntimeSpawnConfig();

            RuntimeReferencesConfig references =
                BuildRuntimeReferencesConfig();

            ExpeditionRuntimeState expeditionRuntime =
                BuildExpeditionRuntimeState();

            SpawnSchedulingContext schedulingContext =
                BuildSchedulingContext(
                    job,
                    spawnConfig,
                    references,
                    expeditionRuntime);

            return new SpawnRuntimeValidationContext(
                schedulingContext,
                spawnConfig,
                references);
        }

        private EnemyVariantData BuildEnemy()
        {
            if (enemy == null)
            {
                throw new InvalidOperationException(
                    "Spawn Runtime Validation requires an EnemyVariantData.");
            }

            return enemy;
        }

        private MaterializableDefinition BuildMaterializable(
            EnemyVariantData enemy)
        {
            if (enemy == null)
                throw new ArgumentNullException(nameof(enemy));

            return new MaterializableDefinition(
                enemy);
        }

        private SpawnExecutionPlanEntry BuildExecutionPlanEntry(
            MaterializableDefinition materializable)
        {
            if (materializable == null)
                throw new ArgumentNullException(nameof(materializable));

            return new SpawnExecutionPlanEntry(
                materializable,
                1);
        }

        private RuntimeReferencesConfig BuildRuntimeReferencesConfig()
        {
            GameObject player =
                new GameObject("SpawnRuntimeValidation_Player");

            return new RuntimeReferencesConfig(
                player.transform);
        }

        private SpawnJobIdentity BuildSpawnJobIdentity()
        {
            return SpawnJobIdentity.New();
        }

        private SpawnJob BuildSpawnJob(
            SpawnJobIdentity identity,
            SpawnExecutionPlanEntry executionEntry)
        {
            return new SpawnJob(
                identity,
                executionEntry);
        }

        private RuntimeSpawnConfig BuildRuntimeSpawnConfig()
        {
            return new RuntimeSpawnConfig(
                SpawnPlacementPolicy.AroundPlayer,
                SpawnActivationPolicy.Immediate,
                Array.Empty<SpawnConstraintPolicy>());
        }

        private ExpeditionRuntimeState BuildExpeditionRuntimeState()
        {
            return new ExpeditionRuntimeState();
        }

        private readonly SpawnSchedulingContextFactory
            schedulingContextFactory =
        new SpawnSchedulingContextFactory();

        private SpawnSchedulingContext BuildSchedulingContext(
            SpawnJob job,
            RuntimeSpawnConfig spawnConfig,
            RuntimeReferencesConfig references,
            ExpeditionRuntimeState expeditionRuntime)
        {
            return schedulingContextFactory.Create(
                job,
                spawnConfig,
                references,
                expeditionRuntime,
                null);
        }
    }
}