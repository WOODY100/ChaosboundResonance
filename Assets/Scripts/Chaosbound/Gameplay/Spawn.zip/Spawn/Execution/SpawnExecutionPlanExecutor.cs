using Chaosbound.Content.Expeditions.Runtime.Enemy;
using Chaosbound.Content.Expeditions.Runtime.References;
using Chaosbound.Content.Expeditions.Runtime.Spawn;
using Chaosbound.Gameplay.Spawn.Domain;
using Chaosbound.Gameplay.Spawn.Factories;
using Chaosbound.Gameplay.Spawn.Models;
using Chaosbound.Gameplay.ExpeditionRuntime.Runtime;
using Chaosbound.Gameplay.Spawn.Scheduling;
using System;
using UnityEngine;
using System.Collections.Generic;

namespace Chaosbound.Gameplay.Spawn.Execution
{
    /// <summary>
    /// Executes SpawnExecutionPlans by coordinating the
    /// execution of every SpawnJob contained in the plan.
    /// </summary>
    public sealed class SpawnExecutionPlanExecutor
    {
        private readonly SpawnJobFactory
            spawnJobFactory;

        private readonly SpawnSchedulingContextFactory
            schedulingContextFactory;

        private readonly SpawnJobExecutor
            spawnJobExecutor;

        /// <summary>
        /// Creates a new SpawnExecutionPlanExecutor.
        /// </summary>
        public SpawnExecutionPlanExecutor(
            SpawnJobFactory spawnJobFactory,
            SpawnSchedulingContextFactory schedulingContextFactory,
            SpawnJobExecutor spawnJobExecutor)
        {
            this.spawnJobFactory =
                spawnJobFactory
                ?? throw new ArgumentNullException(
                    nameof(spawnJobFactory));

            this.schedulingContextFactory =
                schedulingContextFactory
                ?? throw new ArgumentNullException(
                    nameof(schedulingContextFactory));

            this.spawnJobExecutor =
                spawnJobExecutor
                ?? throw new ArgumentNullException(
                    nameof(spawnJobExecutor));
        }

        /// <summary>
        /// Executes the supplied SpawnExecutionPlan.
        /// </summary>
        public IReadOnlyList<GameObject> Execute(
            SpawnExecutionPlan executionPlan,
            RuntimeSpawnConfig spawnConfig,
            RuntimeReferencesConfig references,
            ExpeditionRuntimeState expeditionRuntime)
        {
            if (executionPlan == null)
                throw new ArgumentNullException(nameof(executionPlan));

            if (spawnConfig == null)
                throw new ArgumentNullException(nameof(spawnConfig));

            if (references == null)
                throw new ArgumentNullException(nameof(references));

            if (expeditionRuntime == null)
                throw new ArgumentNullException(nameof(expeditionRuntime));

            List<GameObject> materializedObjects =
                new List<GameObject>();

            IReadOnlyList<SpawnJob> jobs =
                spawnJobFactory.Create(
                    executionPlan);

            foreach (SpawnJob job in jobs)
            {
                SpawnSchedulingContext schedulingContext =
                    schedulingContextFactory.Create(
                        job,
                        spawnConfig,
                        references,
                        expeditionRuntime,
                        executionPlan.Context.SpatialOrigin);

                IReadOnlyList<GameObject> jobObjects =
                    spawnJobExecutor.Execute(
                        schedulingContext);

                foreach (GameObject obj in jobObjects)
                {
                    if (obj != null)
                    {
                        materializedObjects.Add(obj);
                    }
                }
            }

            return materializedObjects;
        }
    }
}