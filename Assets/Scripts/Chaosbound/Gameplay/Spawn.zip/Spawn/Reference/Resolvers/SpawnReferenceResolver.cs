using System;
using System.Collections.Generic;
using Chaosbound.Content.Expeditions.Enums.Spawn;
using Chaosbound.Gameplay.Spawn.Reference.Contracts;
using Chaosbound.Gameplay.Spawn.Reference.Models;

namespace Chaosbound.Gameplay.Spawn.Reference.Resolvers
{
    /// <summary>
    /// Resolves the provider responsible for obtaining
    /// the runtime reference required by the Spawn Runtime.
    /// </summary>
    public sealed class SpawnReferenceResolver
    {
        private readonly IReadOnlyDictionary<
            SpawnPlacementPolicy,
            ISpawnReferenceProvider> providers;

        public SpawnReferenceResolver(
            ISpawnReferenceProvider playerProvider,
            ISpawnReferenceProvider completionOriginProvider)
        {
            if (playerProvider == null)
                throw new ArgumentNullException(
                    nameof(playerProvider));

            if (completionOriginProvider == null)
                throw new ArgumentNullException(
                    nameof(completionOriginProvider));

            providers =
                new Dictionary<
                    SpawnPlacementPolicy,
                    ISpawnReferenceProvider>
                {
                    {
                        SpawnPlacementPolicy.AroundPlayer,
                        playerProvider
                    },
                    {
                        SpawnPlacementPolicy.AroundCompletionOrigin,
                        completionOriginProvider
                    }
                };
        }

        /// <summary>
        /// Resolves the runtime reference.
        /// </summary>
        public SpawnReferenceResult Resolve(
            SpawnReferenceContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            if (context.SpatialOrigin.HasValue)
            {
                return SpawnReferenceResult.Success(
                    context.SpatialOrigin.Value);
            }

            SpawnPlacementPolicy policy =
                context.SpawnConfig.Placement;

            if (!providers.TryGetValue(
                policy,
                out ISpawnReferenceProvider provider))
            {
                return SpawnReferenceResult.Failure(
                    $"No Spawn Reference Provider registered for '{policy}'.");
            }

            return provider.Resolve(context);
        }
    }
}